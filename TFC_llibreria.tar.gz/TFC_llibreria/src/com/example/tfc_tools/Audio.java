package com.example.tfc_tools;



import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;


// TODO: Auto-generated Javadoc
/**
 * La classe <b>Audio</b> és una extensió d'AudioRecord.
 * 
 * @author Amador Criado
 * @version 1.0
 * @since 02-jun-2014
 * @category Desenvolupament Android
 */
public class Audio extends AudioRecord {
	

	/** The Constant RECORDER_BPP. */
	private static final int RECORDER_BPP = 16;
	
	/** The Constant RECORDER_SAMPLERATE. */
	private static final int RECORDER_SAMPLERATE = 8000;
	
	/** The Constant RECORDER_CHANNELS. */
	private static final int RECORDER_CHANNELS = AudioFormat.CHANNEL_IN_STEREO;
	
	/** The Constant RECORDER_AUDIO_ENCODING. */
	private static final int RECORDER_AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT;
	
	/** The Constant TFC. */
	private static final String TFC= "TFC";
	
	/** The channels. */
	private static short channels=2;
	
	/** The record. */
	private AudioRecord record;
	
	/** The track. */
	private AudioTrack track;
	
	 /** The max jitter. */
 	int maxJitter;
	 
 	/** The buffer size. */
 	private int bufferSize=2048;
	
		/**
		 * Instantiates a new audio.
		 * 
		 * @param audioSource
		 *            the audio source
		 * @param sampleRateInHz
		 *            the sample rate in hz
		 * @param channelConfig
		 *            the channel config
		 * @param audioFormat
		 *            the audio format
		 * @param bufferSizeInBytes
		 *            the buffer size in bytes
		 * @throws IllegalArgumentException
		 *             the illegal argument exception
		 */
		public Audio(int audioSource, int sampleRateInHz, int channelConfig,
				int audioFormat, int bufferSizeInBytes)
				throws IllegalArgumentException {
			
			super(audioSource, sampleRateInHz, channelConfig, audioFormat,
					bufferSizeInBytes);
			
			this.maxJitter = AudioTrack.getMinBufferSize(8000, RECORDER_CHANNELS, RECORDER_AUDIO_ENCODING);
			this.setTrack(new AudioTrack(AudioManager.MODE_IN_COMMUNICATION, 8000, RECORDER_CHANNELS,
					RECORDER_AUDIO_ENCODING, maxJitter, AudioTrack.MODE_STREAM));
			
			
			
		}

	
	/**
	 * Gets the buffer size.
	 * 
	 * @return the buffer size
	 */
	public int getBufferSize(){
		
		return this.bufferSize;
	}
	
	/**
	 * Gets the recorder.
	 * 
	 * @return the recorder
	 */
	public AudioRecord getRecorder(){
		return this.getRecord();
		
	}
	
	/**
	 * Start.
	 */
	public void start(){
		this.startRecording();
	}
	
	/**
	 * Destroy.
	 */
	public void destroy() {

			this.release();

	}



	/**
	 * Rec.
	 * 
	 * @param b
	 *            the b
	 */
	public void rec(byte[] b){
		
		int num=this.getRecord().read(b,0, this.getBufferSize());
	
		
	}
	
	/**
	 * Play.
	 * 
	 * @param b
	 *            the b
	 * @return the int
	 */
	public int play(byte[] b){
		int num=getTrack().write(b,0,getBufferSize());
		getTrack().play();
		
		if(AudioTrack.ERROR_INVALID_OPERATION != num){
			return num;
		}else{
			return AudioTrack.ERROR_INVALID_OPERATION;
		}
	}


	/**
	 * @return the record
	 */
	public AudioRecord getRecord() {
		return record;
	}


	/**
	 * @param record the record to set
	 */
	public void setRecord(AudioRecord record) {
		this.record = record;
	}


	/**
	 * @return the track
	 */
	public AudioTrack getTrack() {
		return track;
	}


	/**
	 * @param track the track to set
	 */
	public void setTrack(AudioTrack track) {
		this.track = track;
	}


	/**
	 * @param bufferSize the bufferSize to set
	 */
	public void setBufferSize(int bufferSize) {
		this.bufferSize = bufferSize;
	}
	


}
