/*
 * 
 */
package com.example.tfc_tools;

import java.nio.ByteBuffer;

import android.util.Log;

// TODO: Auto-generated Javadoc
/**
 * La classe <b>FX</b> conté totes les funcions que processan la informació continguda als buffers
 * @author Amador Criado
 * @version 1.0
 * @since 02-jun-2014
 * @category Desenvolupament Android
 */
public class FX {
	

		
	/**
	 * Instantiates a new fx.
	 */
	public FX() {

		
	}

	
	/**
	 * Llindar alt.
	 * 
	 * @param b
	 *            the b
	 * @param limit
	 *            the limit
	 * @return the byte buffer
	 */
	public ByteBuffer llindarAlt(ByteBuffer b, int limit){

		ByteBuffer b2=b.duplicate();
		byte by;
		int valor;
		byte blimit = (byte) limit;

		for(int i=0;i<1020;i++){
			by=b2.get(i);
			valor=(int) (by);


			if (valor>limit && valor>0){

				b2.put(i,blimit);
			}
		}


		return b2;


	}


	/**
	 * Llindar baix.
	 * 
	 * @param b
	 *            the b
	 * @param limit
	 *            the limit
	 * @return the byte buffer
	 */
	public ByteBuffer llindarBaix(ByteBuffer b,int limit){
		ByteBuffer b2=b.duplicate();
		byte by;
		int valor;
		byte blimit = (byte) limit;
		
		for(int i=0;i<1020;i++){
			by=b2.get(i);
			valor=(int) (by);
			
			
			if (valor<limit && valor<0){
				b2.put(i,blimit);
				
			}
	}
		
		
		return b2;
	
		
	}
	
	
	/**
	 * Doble llindar.
	 * 
	 * @param b
	 *            the b
	 * @param limitAlt
	 *            the limit alt
	 * @param limitBaix
	 *            the limit baix
	 * @param n
	 *            the n
	 * @return the byte buffer
	 */
	public ByteBuffer dobleLlindar(ByteBuffer b,int limitAlt,int limitBaix,int n){
		int valor;
		ByteBuffer b2=b.duplicate();

		int size=b2.capacity();

		for(int i=0;i<size;i++){
			
			valor=(int) (b2.get(i));
			
			
			if (valor<limitBaix && valor<0){
				b2.put(i,(byte)limitBaix);
				
				
			}else if(valor>limitAlt && valor>0) {
				
				b2.put(i,(byte)limitAlt);
			}
				
	}

		return b2;
	
		
	}
	

	/**
	 * Gets the energy.
	 * 
	 * @param b
	 *            the b
	 * @return the energy
	 */
	public int getEnergy(ByteBuffer b){
		
		int valor;
		ByteBuffer b2=b.duplicate();
		int pos=0;
		int i=0;
		int n=0;


		while(i<2048){
			valor=(int) (b2.get(i));
			if(valor<0){
				valor=valor*(-1);
				
			}
			pos=pos+valor;
			i=i+48;
			n++;
			
		}
		pos=(pos/n);
		return pos;

	}
	

}
