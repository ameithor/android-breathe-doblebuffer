/*
 * 
 */
package com.example.tfc_tools;

import java.nio.ByteBuffer;
import android.media.AudioFormat;
import android.media.MediaRecorder;
import android.os.AsyncTask;

// TODO: Auto-generated Javadoc
/**
 * La classe <b>DobleBuffer</b> Consisteix en el processat de dos buffers
 * d'audio en temps real. Instànciant aquesta classe en qualsevol aplicació
 * és pot saber en qualsevol moment si l'usuari està <b>inspirant</b>, en 
 * <b>pausa</b>, o <b>expirant</b>.
 * <br>
 * <b>buffer1: </b> Primer Buffer principal
 * <br>
 * <b>buffer2: </b> Segon  Buffer principal
 * <br>
 * <b>buffer3Aux: </b> primer Buffer secundari
 * <br>
 * <b>buffer4Aux: </b> Segon  Buffer secundari
 * <br>
 * 
 * @author Amador Criado
 * @version 1.0
 * @since 02-jun-2014
 * @category Desenvolupament Android
 * @permission android.permission.WRITE_EXTERNAL_STORAGE <br>
 * android.permission.MODIFY_AUDIO_SETTINGS <br>
 * android.permission.RECORD_AUDIO <br>
 */
public class DobleBuffer extends AsyncTask<Integer,Integer,Integer> {

	/** The Constant DEFAULT_RECORDER_SAMPLERATE. */
	private static final int DEFAULT_RECORDER_SAMPLERATE = 8000;
	
	/** The Constant DEFAULT_RECORDER_CHANNELS. */
	private static final int DEFAULT_RECORDER_CHANNELS = AudioFormat.CHANNEL_IN_STEREO;
	
	/** The Constant DEFAULT_RECORDER_AUDIO_ENCODING. */
	private static final int DEFAULT_RECORDER_AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT;
	
	/** The Constant DEFAULT_BUFFERSIZE. */
	private static final int DEFAULT_BUFFERSIZE = 2048;
	
	/** The bpp. */
	private int  bpp;
	
	/** The samplerate. */
	private int  samplerate;
	
	/** The channels. */
	private int  channels;
	
	/** The audio_encoding. */
	private int  audio_encoding;
	
	/** The buffersize. */
	private int  buffersize;
	
	
	/** The breath in. */
	private boolean breathIn;
	
	/** The breath hold. */
	private boolean breathHold;
	
	/** The breath out. */
	private boolean breathOut;
	

	/** Primer Buffer principal
	 * <br>
	 * <b>tipus: </b> ByteBuffer
	 *  */
	private ByteBuffer buffer1;
	
	/** Segon Buffer principal
	 * <br>
	 * <b>tipus: </b> ByteBuffer
	 *  */
	private ByteBuffer buffer2;
	
	/** Primer Buffer secundari
	 * <br>
	 * <b>tipus: </b> ByteBuffer
	 *  */
	private ByteBuffer buffer3Aux;
	
	/** Segon Buffer secundari
	 * <br>
	 * <b>tipus: </b> ByteBuffer
	 *  */
	private ByteBuffer buffer4Aux;

	/** Instància de la classe <b>FX</b>, es fa servir principalment per captar l'energia 
	 * del só buffers mitjançant el procediment <em>getEnergy(ByteBuffer b)</em>*/
	private FX fx;
	
	/**  Instància de la classe <b>Audio</b> que hereta d'<b>AudioRecord</b>*/
	private Audio audio;
	

	
	/** n fa referència a la iteració del bucle principal de la classe dobleBiffer*/
	private int n=0;
	
	/** The valor. */
	private int valor=0;
	
	/** The energy. */
	private  int energy=-1;
	
	/** The media. */
	private int media=0;
	
	/** The param estat. */
	private  Integer paramEstat=0;
	
	/** The num. */
	private int num = 0;
	
	/** The estat. */
	private int estat;
	
	/** The acum. */
	private int acum=0;
	
	/** The i. */
	private int i;
	
	
	/** Mientras Continuar true el thread DobleBuffer segueix en funcionament. */
	private boolean continuar = true;
	

		
	/**
	 * Constructor Doblebuffer<br>.
	 * Fa servir les constants definides a la clase per inicialitzar l'atribut <b<audio</b><br>
	 * MediaRecorder.AudioSource.MIC<br>
	 * DEFAULT_RECORDER_SAMPLERATE<br>
	 * DEFAULT_RECORDER_CHANNELS<br>
	 * DEFAULT_RECORDER_AUDIO_ENCODING<br>
	 * DEFAULT_BUFFERSIZE<br>
	 */
	public DobleBuffer(){
		fx = new FX();
		audio=new Audio(MediaRecorder.AudioSource.MIC, DEFAULT_RECORDER_SAMPLERATE, 
				DEFAULT_RECORDER_CHANNELS, DEFAULT_RECORDER_AUDIO_ENCODING, DEFAULT_BUFFERSIZE);

	}
	
	

	/* (non-Javadoc)
	 * @see android.os.AsyncTask#onPreExecute()
	 */
	protected void onPreExecute() {

		buffer1 = ByteBuffer.allocate(audio.getBufferSize());
		buffer2 = ByteBuffer.allocate(audio.getBufferSize());
		buffer3Aux = ByteBuffer.allocate(audio.getBufferSize());
		buffer4Aux = ByteBuffer.allocate(audio.getBufferSize());

		breathIn=false;
		breathHold=false;
		breathOut=true;

		n=0;
		valor=0;
		estat=10;
		media=0;

	}


	/**
	 * Checks if is breathing in.
	 * 
	 * @return true, if is breathing in
	 */
	protected boolean isBreathingIn(){
		if(breathIn){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Checks if is breathing hold.
	 * 
	 * @return true, if is breathing hold
	 */
	protected boolean isBreathingHold(){
		if(breathHold){
			return true;
		}else{
			return false;
		}
	}


	/**
	 * Checks if is breathing out.
	 * 
	 * @return true, if is breathing out
	 */
	protected boolean isBreathingOut(){
		if(breathOut){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Gets the buffer1.
	 * 
	 * @return the buffer1
	 */
	protected ByteBuffer getBuffer1(){
		return this.buffer1;
	}
	
	/**
	 * Gets the buffer2.
	 * 
	 * @return the buffer2
	 */
	protected ByteBuffer getBuffer2(){
		return this.buffer2;
	}
	
	/**
	 * Gets the buffer3 aux.
	 * 
	 * @return the buffer3 aux
	 */
	protected ByteBuffer getBuffer3Aux(){
		return this.buffer3Aux;
	}
	
	/**
	 * Gets the buffer4 aux.
	 * 
	 * @return the buffer4 aux
	 */
	protected ByteBuffer getBuffer4Aux(){
		return this.buffer4Aux;
	}
		

	/* (non-Javadoc)
	 * @see android.os.AsyncTask#doInBackground(Params[])
	 */
	protected Integer doInBackground(Integer... arg0) {

		audio.startRecording();


		while (continuar) {

			//** Buffer 1 **//
			num=audio.read(buffer1.array(),0,2048);
			buffer3Aux=buffer1.duplicate();
			
			//** Buffer 2 **//
			num=audio.read(buffer2.array(),0,2048);
			energy=fx.getEnergy(buffer3Aux);


			buffer4Aux=buffer2.duplicate();
			
			if (n<5){
				
			acum=acum+energy;
			
			}else{

			n=0;
			media=acum;
			acum=0;
			
			}
			
			if(estat==10){
				if(media>80){
					estat=1;
				}
			}
			if(estat==1){
				if(media<75){
					estat=20;
					
				}
			}
			if(estat==20){
				if(media>80){
					estat=2;
				}
			}
			if(estat==2){
				if(media<75){
					estat=30;
				}
			}
			if(estat==30){
				if(media>80){
					estat=1;
				}
			}
			n++;
			paramEstat=estat;
			publishProgress(paramEstat);
		}

		return 0;
	}



	/**
	 * Refresh energy.
	 * 
	 * @param status
	 *            the status
	 */
	private  void refreshEnergy(int status){

		switch(status){
			case 1:{
				this.showProgress(1,0,0);
				break;
			}case 20:{
				this.showProgress(0,1,0);
				break;
			}case 2:{
				this.showProgress(0,0,1);
				break;
			}case 30:{
				this.showProgress(0,1,0);
				break;
			}

		}

	}

	/**
	 * Show progress.
	 * 
	 * @param in
	 *            inspirant...
	 * @param hold
	 *            mantenint aire..
	 * @param out
	 *            expirant....
	 */
	private  void showProgress(int in,int hold,int out){

		if(in==1){
			this.breathIn=true;
		}else if(out==1){
			this.breathOut=true;
		}else if(hold==1){
			this.breathHold=true;
		}

	}
	
	
	/* (non-Javadoc)
	 * @see android.os.AsyncTask#onProgressUpdate(Progress[])
	 */
	@Override
	protected void onProgressUpdate(Integer... values) {
		super.onProgressUpdate(values);
		refreshEnergy(values[0]);

	}

	/* (non-Javadoc)
	 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
	 */
	protected void onPostExecute (Integer result){
		super.onPostExecute(result);
        audio.destroy();
        audio.release();
        audio=null;
	}
	
	/**
	 * Parar.
	 */
	public void parar()
	{
		audio.destroy();
	}

	/**
	 * Destruir.
	 */
	public void destruir()
	{


        this.continuar=false;
        

	}


	/**
	 * Gets the bpp.
	 * 
	 * @return the bpp
	 */
	protected int getBpp() {
		return bpp;
	}


	/**
	 * Sets the bpp.
	 * 
	 * @param bpp
	 *            the new bpp
	 */
	protected void setBpp(int bpp) {
		this.bpp = bpp;
	}


	/**
	 * Gets the samplerate.
	 * 
	 * @return the samplerate
	 */
	protected int getSamplerate() {
		return samplerate;
	}


	/**
	 * Sets the samplerate.
	 * 
	 * @param samplerate
	 *            the new samplerate
	 */
	protected void setSamplerate(int samplerate) {
		this.samplerate = samplerate;
	}


	/**
	 * Gets the channels.
	 * 
	 * @return the channels
	 */
	protected int getChannels() {
		return channels;
	}


	/**
	 * Sets the channels.
	 * 
	 * @param channels
	 *            the new channels
	 */
	protected void setChannels(int channels) {
		this.channels = channels;
	}


	/**
	 * Gets the audio_encoding.
	 * 
	 * @return the audio_encoding
	 */
	protected int getAudio_encoding() {
		return audio_encoding;
	}


	/**
	 * Sets the audio_encoding.
	 * 
	 * @param audio_encoding
	 *            the new audio_encoding
	 */
	protected void setAudio_encoding(int audio_encoding) {
		this.audio_encoding = audio_encoding;
	}


	/**
	 * Gets the buffersize.
	 * 
	 * @return the buffersize
	 */
	protected int getBuffersize() {
		return buffersize;
	}


	/**
	 * Sets the buffersize.
	 * 
	 * @param buffersize
	 *            the new buffersize
	 */
	protected void setBuffersize(int buffersize) {
		this.buffersize = buffersize;
	}






}